package java_lang;

import java.math.BigInteger;

public class ex2 {
    public static void main(String[] args) {

    }
}
