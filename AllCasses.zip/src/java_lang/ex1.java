package java_lang;

import java.util.Scanner;

public class ex1 {
    public static void main(String[] args) {
        Scanner n = new Scanner(System.in);
        String a = n.nextLine();
        System.out.println(a);
    }
}
