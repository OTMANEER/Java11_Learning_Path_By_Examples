public class Foo <T>{
    T x;

    public Foo(T x) {
        this.x = x;
    }
}
