package polymorphism.moreInterf;

public class B implements A{
    @Override
    public void string() {
        System.out.println("NOTHING TO DO");
    }
}
