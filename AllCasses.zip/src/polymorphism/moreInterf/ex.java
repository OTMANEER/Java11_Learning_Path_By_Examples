package polymorphism.moreInterf;

public class ex {
    public static void main(String[] args) {
        B b= new B();
        System.out.println(b instanceof A);
    }
}
