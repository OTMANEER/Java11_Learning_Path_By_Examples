package polymorphism.moreInterf;

@myAnnotation(value = 101)
public class Not {
    @myAnnotation
    public Not(){
    }

}
