package polymorphism.moreInterf;

public interface C {
    default void m(){
        System.out.println("OTMANE FROM C");
    };
}
