package polymorphism.moreInterf;

public interface A {
    default void string(){
        System.out.println("otmane");
    };
}
