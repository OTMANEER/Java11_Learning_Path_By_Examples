package polymorphism.moreInterf;

public class D {
    public void string(){
        System.out.println("FROM D");
    }
    public void m(){
        System.out.println("FROM D too this m");
    }
}
