package polymorphism;

public class B extends A{
    String name;
    int age;
    void m(){
        System.out.println("From the class B");
    }
}
