package polymorphism;

public class A {
    int x;
    void m(){
        System.out.println("OTMANE FROM NonOrgr.A");
    }
}
