package polymorphism.static_inter;

public class ElectricEngine implements Engine{
    @Override
    public void run() {
        System.out.println("This Work");
    }
}
