package polymorphism.static_inter;

public interface Engine {
    void run();
}
