package polymorphism.static_inter;

public class DieselEngine implements Engine{
    @Override
    public void run() {
        System.out.println("Diesel");
    }
}
