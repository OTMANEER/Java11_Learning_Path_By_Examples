package polymorphism.static_inter;

public class EngineFactory {
    private EngineFactory(){};


}
