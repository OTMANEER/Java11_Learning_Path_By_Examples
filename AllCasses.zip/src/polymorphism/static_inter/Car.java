package polymorphism.static_inter;

public class Car {
    private Engine engine;
    public Car() {
        this.engine = new ElectricEngine();
    }

}
