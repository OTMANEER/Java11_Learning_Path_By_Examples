package polymorphism.oneLastExample;

import java.util.Set;

public class Panda extends Bear {
    public Integer chew() { return 10; }

    public Panda() {
        super();
    }

    public static void main(String[] args) {

        Set<Integer> set= Set.of(1,2,3);

    }

}
