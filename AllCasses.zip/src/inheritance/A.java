package inheritance;

public class A {
    int x;
    private int age;

    void m(){
        System.out.println("OTMANE");
    }
}
