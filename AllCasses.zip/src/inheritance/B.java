package inheritance;

public class B extends A{
    int age1;
    public static void main(String[] args) {
        B b = new B();
        b.m();
    }
}
