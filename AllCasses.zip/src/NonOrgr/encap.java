package NonOrgr;

public class encap {
    private int age;
    private String name;

    public encap(int age, String name) {
        this.age = age;
        this.name = name;
    }
}
