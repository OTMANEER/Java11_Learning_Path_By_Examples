package NonOrgr;

public class united {
    public static void main(String... args) {
        char a = '\u0065';
        boolean b = false;
        System.out.println(a+" "+b);
    }
}
