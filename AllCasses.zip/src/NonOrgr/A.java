package NonOrgr;

public class A {
    int age;
    public A( ) {

    }
    public A(int age) {

    }

    public A(double age) {

    }
    public static void main(String[] args) {
    A a= new A();
    }
}
