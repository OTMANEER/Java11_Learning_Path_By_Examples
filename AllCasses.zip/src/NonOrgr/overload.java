package NonOrgr;

public class overload {
    void a(){
        System.out.println("HAHA  NOTHING");
    }
    void a(int a){
        System.out.println("HAHA  I AM THE SECOND OPTION");
    }

    public static void main(String[] args) {

    }
}
