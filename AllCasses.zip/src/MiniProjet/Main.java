package MiniProjet;

public class Main {
    public static void main(String[] args) {
/*

        PieceDeBase pieceDeBase = new PieceDeBase("TaRo",11.2F);
        PieceDeBase pieceDeBase1 = new PieceDeBase("KACHA",1.2F);
        PieceComposite pieceComposite1 = new PieceComposite("Cuisine");
        PieceComposite pieceComposite2 = new PieceComposite("Toilette");

        pieceComposite1.ajouter_piece(pieceDeBase,2);
        pieceComposite1.ajouter_piece(pieceDeBase,2);
        pieceComposite2.ajouter_piece(pieceDeBase1,10);
        pieceComposite2.ajouter_piece(pieceDeBase1,10);
        pieceComposite1.ajouter_piece(pieceComposite2,1);
*/

/*           try{
             System.out.println(pieceComposite.getPoid());
             pieceComposite.affiche_tous_sous_pieces(10);
          } catch (Exception e) {
               System.out.println("We are Sorry A lot of Exceptions appear in  this banch of code");
           }*/

     /*    Nomenclature nomenclature = new Nomenclature("JPDL");
         nomenclature.ajouter(123,pieceDeBase );
         nomenclature.ajouter(1255,pieceDeBase1);
         nomenclature.ajouter(124,pieceComposite1);
         nomenclature.ajouter(124,pieceComposite1);
         nomenclature.ajouter(124,pieceComposite1);
         nomenclature.ajouter(124,pieceComposite1);
        try {
            System.out.println(nomenclature.toString());
        } catch (Exception e) {
            System.out.println("We have an exception");
        }*/
        /*
        Piece p = nomenclature.chercherUnePiece(121);
        System.out.println(p);*/
        // nomenclature.afficher_toutes_pieces_composites(pieceComposite1);
/*       nomenclature.supprimer_piece(pieceDeBase1);
        System.out.println("------------------------------------------");
        try {
            System.out.println(nomenclature.toString());
        } catch (Exception e) {
            System.out.println("We have an exception");
        }*/
        Nomenclature nomenclature = new Nomenclature("TEST");
        nomenclature.Menu();

    }

}

// 2.1:  Une grande quantité des exceptions sera levées


