package MiniProjet;

public class MainMenu {
    public static void main(String[] args) {
        PieceParticuliere pp1 = new PieceParticuliere("Lampe",20);
        PieceComposite pc1 = new PieceComposite("Cadre");
        PieceComposite pc2 = new PieceComposite("Petit Cadre");
        PieceDeBase pb1 = new PieceDeBase("Plaque de Vert",2);
        PieceDeBase pb2 = new PieceDeBase("2eme Plaque de Vert",3);
        pc1.ajouter_piece(pc2,2);
        pc1.ajouter_piece(pb1,31);
        pc1.ajouter_piece(pb2,4);
    }
}
