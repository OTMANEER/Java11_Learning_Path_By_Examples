package example3;

public class Dog extends Animal{
}
