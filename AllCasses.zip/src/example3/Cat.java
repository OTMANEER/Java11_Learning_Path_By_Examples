package example3;

public class Cat extends Animal{
}
