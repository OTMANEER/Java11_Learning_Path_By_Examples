package example3;

public interface deplaceable {
    public void m(int c,int cv);

}
