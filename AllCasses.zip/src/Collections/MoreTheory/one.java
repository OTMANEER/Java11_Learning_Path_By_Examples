package Collections.MoreTheory;

import java.util.*;
public class one {
    public static void main(String[] args) throws Exception{
   /*     Random random = new Random();
        for(int i = 1;i<1000;i++) {
           int d =(int) Math.random();
      //         if (d>8)
               System.out.print(d+" ");

        }*/

        /*        Map<String,String> map = new HashMap<>();
        map.put("otman","salaah");
        map.put("otman","salaah");
        System.out.println(map.getOrDefault("otmsan","Walo"));
        // atthe first itdoesn't really comes with this today let's try a problem here!*/

     /*   List<Integer> list =List.of(1,2,31,101,1,2,21,2,31,101);
        // Another useful way to define this now
        List<Double> list1 = Arrays.asList(1D,2D,2D,1D,12D,1.1);
        System.out.println(list);
        System.out.println(list1);
        Collections.shuffle(list);*/
        // this was defined today before the last element was announced today and we got to work on it as soon as possbible

        /* list.add(15);
        list1.add(10);
        list1.add(11);
        list1.add(12);
        list1.add(15);
        list1.add(13);
        list1.add(14);*/


// Many way to define this before your really leave a comment section here and this can work just perfectly	
        // we can define an iterator ot iterate over t elist now

    }

}
