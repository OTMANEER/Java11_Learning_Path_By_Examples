package Collections.example1; 
import java.util.*;

public class first {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        List<Integer> list1 = new LinkedList<>();

list.add(1111);
list1.add(999);

int a = list.get(0); // No problem

List<Animal> l = new ArrayList<>();

l.add(new cat());

        System.out.println(list );
        System.out.println(list1 );
    }
}


