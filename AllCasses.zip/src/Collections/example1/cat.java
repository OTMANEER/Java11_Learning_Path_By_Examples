package Collections.example1;


public class cat extends  Animal {

}
class otmane{
    int a;
    int age;
    float height;
    String name;

    public otmane(int age, float height, String name) {
        this.age = age;
        this.height = height;
        this.name = name;
    }
}