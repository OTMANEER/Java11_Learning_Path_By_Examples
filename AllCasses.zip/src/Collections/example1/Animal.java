package Collections.example1;

public class Animal {

    public Animal() {
    }
}
