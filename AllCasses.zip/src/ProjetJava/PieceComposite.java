package ProjetJava;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PieceComposite extends Piece{
    Map<Piece,Integer> listPiece;
}

/*
example:

    Piece composite:  Cuisine contient:
                                        {
                                            placard,
                                        }
*/
