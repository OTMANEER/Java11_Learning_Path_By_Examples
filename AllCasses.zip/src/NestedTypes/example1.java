package NestedTypes;

public class example1 {

    public static void main(String[] args) {

        A1.A3 a3 = new A1.A3();

        A1 a1 = new A1();
        A1.A2 a2 = a1.new A2();

    }
}
