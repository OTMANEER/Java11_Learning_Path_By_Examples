package Youssef;

public class Animal {
}
