package Random.Tests;

public interface ran {

    default void dont(){
        System.out.println("je vais bien");
    }
}
