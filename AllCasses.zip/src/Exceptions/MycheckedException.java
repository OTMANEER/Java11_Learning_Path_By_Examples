package Exceptions;

public class MycheckedException extends Exception{
    public MycheckedException(){
        super("My checked exception");
    }

    public static void main(String[] args) {
    }
}
