package Exceptions;

public class muchMoneyException extends RuntimeException{
}
