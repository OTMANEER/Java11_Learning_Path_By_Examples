package Exceptions.more;

import Exceptions.muchMoneyException;

public interface I {
    void m() ;

}
