package Exceptions.more;

import Exceptions.muchMoneyException;

public class TEST implements I{
    protected void m(int a) {

    }
    @Override
    public void m() {

    }
}
