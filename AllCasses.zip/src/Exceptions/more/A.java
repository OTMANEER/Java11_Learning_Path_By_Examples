package Exceptions.more;

import Exceptions.muchMoneyException;

public class A {
    public void m() throws muchMoneyException {

    }
}
