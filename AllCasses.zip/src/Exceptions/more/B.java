package Exceptions.more;

import Exceptions.muchMoneyException;

public class B extends A{
    @Override
    public void m() throws muchMoneyException {

    }
}
