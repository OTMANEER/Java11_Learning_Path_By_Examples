public class lasGen {
    static <T> void smth(T a, Class<T> c){
    }

    public static void main(String[] args) {
     smth(10.0 ,Double.class);
    }
}
