package LambdaExpressions.part4;

public class ex {
    public static void main(String[] args) {
        coffee c =  coffee.BILAL;
        c.getQty();
        c.setQty(10);
        System.out.println(c.ordinal());
    }
}
