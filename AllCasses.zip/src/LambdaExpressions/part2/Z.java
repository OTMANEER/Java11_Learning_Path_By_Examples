package LambdaExpressions.part2;

public interface Z {
    int v();
}
