package LambdaExpressions.part3;

public interface reverse {
    String reverse(String in);
}
