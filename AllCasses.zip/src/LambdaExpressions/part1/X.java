package LambdaExpressions.part1;

public interface X {

    void mm(int a,int b);
    default void m(int x){ };
}
